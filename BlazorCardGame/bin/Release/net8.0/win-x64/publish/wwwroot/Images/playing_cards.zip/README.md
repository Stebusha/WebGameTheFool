# Playing cards asset pack

This is a free asset pack made by Victor MEUNIER. You can use this for personnal and commercial projects. 
If you can, please credit me.

<!-- LICENSE -->
## License

Distributed under the [CC0 license](http://creativecommons.org/publicdomain/zero/1.0/). See [LICENCE](LICENCE) for more information.

<!-- CONTACT -->
## Contact

Victor MEUNIER - victormeunier.dev@gmail.com

- [Website](https://www.victormeunier.com)
- [Blog](https://blog.victormeunier.com)
- [@VicMeunier](https://twitter.com/VicMeunier)
- [Itch.io](https://mreliptik.itch.io/)
- [Sketchfab](https://sketchfab.com/mreliptik)


You like my work and want to support me? 

<a href="https://www.buymeacoffee.com/mreliptik" target="_blank"><img src="https://bmc-cdn.nyc3.digitaloceanspaces.com/BMC-button-images/custom_images/orange_img.png" alt="Buy Me A Coffee" style="height: auto !important;width: auto !important;" ></a>

